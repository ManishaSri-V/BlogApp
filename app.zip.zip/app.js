require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = process.env.PORT || 3000;


mongoose.connect(process.env.MONGO_URL);
mongoose.connection.on('error', console.error.bind(console, 'MongoDB connection error:'));


const BlogPost = mongoose.model('BlogPost', {
    title: String,
    content: String,
});


app.use(bodyParser.json());


app.use(express.static('public'));


app.get('/api/blog-posts', async (req, res) => {
    try {
        const blogPosts = await BlogPost.find();
        res.json(blogPosts);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


app.post('/api/blog-posts', async (req, res) => {
    const { title, content } = req.body;

    try {
        const newPost = await BlogPost.create({ title, content });
        res.status(201).json(newPost);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


app.listen(port, () => {
    console.log(`Server is listening at http://localhost:${port}`);
});

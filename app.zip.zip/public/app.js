document.addEventListener('DOMContentLoaded', async function () {
    const blogPostsContainer = document.getElementById('blog-posts');

    
    async function fetchAndDisplayBlogPosts() {
        try {
            const response = await fetch('/api/blog-posts');
            const blogPosts = await response.json();

            
            blogPostsContainer.innerHTML = '';

         
            blogPosts.forEach(post => {
                const postElement = document.createElement('div');
                postElement.classList.add('blog-post');
                postElement.innerHTML = `
                    <h2>${post.title}</h2>
                    <p>${post.content}</p>
                `;
                blogPostsContainer.appendChild(postElement);
            });
        } catch (error) {
            console.error('Error fetching blog posts:', error);
        }
    }

    
    await fetchAndDisplayBlogPosts();

    
    const form = document.getElementById('blog-form');
    form.addEventListener('submit', async function (event) {
        event.preventDefault();

        const titleInput = document.getElementById('title');
        const contentInput = document.getElementById('content');

        const title = titleInput.value;
        const content = contentInput.value;

        if (title && content) {
            try {
                await fetch('/api/blog-posts', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ title, content }),
                });

                
                titleInput.value = '';
                contentInput.value = '';

                
                await fetchAndDisplayBlogPosts();
            } catch (error) {
                console.error('Error creating blog post:', error);
            }
        }
    });
});
